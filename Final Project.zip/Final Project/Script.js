window.onload = function() {
    var path = document.getElementById('path3558');
    var plane = document.getElementById('plane');
    path.parentNode.replaceChild(plane, path);
};